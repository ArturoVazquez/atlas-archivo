<!--SLD file created with GeoCat Bridge v2.5.0 using ArcGIS Desktop with Geoserver extensions.
 Date: 14 mayo 2022
 See www.geocat.net for more details-->
<StyledLayerDescriptor xmlns="http://www.opengis.net/sld"
                     	xmlns:ogc="http://www.opengis.net/ogc"
                     	xmlns:xlink="http://www.w3.org/1999/xlink"
                     	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     	xsi:schemaLocation="http://www.opengis.net/sld http://schemas.opengis.net/sld/1.0.0/StyledLayerDescriptor.xsd"
                     	version="1.0.0">
	<NamedLayer>
		<Name>IDENA_ENERGI_Pol_PSolar</Name>
		<UserStyle>
			<Name>IDENA_ENERGI_Pol_PSolar</Name>
			<Title>IDENA_ENERGI_Pol_PSolar</Title>
			<FeatureTypeStyle>
				<Rule>
					<MaxScaleDenominator>3000000</MaxScaleDenominator>
					<PolygonSymbolizer>
						<Stroke>
							<CssParameter name="stroke">#5fe827</CssParameter>
							<CssParameter name="stroke-width">1</CssParameter>
						</Stroke>
					</PolygonSymbolizer>
					<PolygonSymbolizer>
						<Fill>
							<GraphicFill>
								<Graphic>
									<Mark>
										<WellKnownName>ttf://Arial#215</WellKnownName>
										<Fill>
											<CssParameter name="fill">#90b083</CssParameter>
										</Fill>
									</Mark>
									<Opacity>0</Opacity>
									<Size>4</Size>
								</Graphic>
							</GraphicFill>
						</Fill>
						<!-- 						<Stroke>
							<CssParameter name="stroke">#965B5B</CssParameter>
							<CssParameter name="stroke-width">0.1</CssParameter>
						</Stroke> -->
					</PolygonSymbolizer>
				</Rule>
				<Rule>
					<MaxScaleDenominator>50000</MaxScaleDenominator>
					<TextSymbolizer>
						<Label>
							<ogc:PropertyName>"           "</ogc:PropertyName>
							<ogc:PropertyName>"PLANTA SOLAR "</ogc:PropertyName>
							<ogc:PropertyName>NOMBRE</ogc:PropertyName>
						</Label>
						<Font>
							<CssParameter name="font-family">Calibri</CssParameter>
							<CssParameter name="font-size">15</CssParameter>
							<CssParameter name="font-style">normal</CssParameter>
							<CssParameter name="font-weight">normal</CssParameter>
						</Font>
<!-- 						<LabelPlacement>
							<LinePlacement>
								<PerpendicularOffset>10</PerpendicularOffset>
							</LinePlacement>
						</LabelPlacement> -->
						<Halo>
							<Radius>1.5</Radius>
							<Fill>
								<CssParameter name="fill">#90b083</CssParameter>
							</Fill>
						</Halo>
						<Fill>
							<CssParameter name="fill">#FFFFFF</CssParameter>
						</Fill>
						<!-- <VendorOption name="followLine">true</VendorOption> -->
						<!-- <VendorOption name="group">yes</VendorOption> -->
					</TextSymbolizer>
				</Rule>
			</FeatureTypeStyle>
		</UserStyle>
	</NamedLayer>
</StyledLayerDescriptor>
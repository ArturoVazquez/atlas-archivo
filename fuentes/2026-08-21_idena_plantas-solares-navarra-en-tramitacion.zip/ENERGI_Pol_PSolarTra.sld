<?xml version="1.0" encoding="UTF-8"?>
<sld:StyledLayerDescriptor xmlns="http://www.opengis.net/sld" xmlns:sld="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" xmlns:gml="http://www.opengis.net/gml" version="1.0.0">
	<sld:NamedLayer>
		<sld:Name>IDENA_ENERGI_Pol_PSolarTra</sld:Name>
		<sld:UserStyle>
			<sld:Name>IDENA_ENERGI_Pol_PSolarTra</sld:Name>
			<sld:Title>IDENA_ENERGI_Pol_PSolarTra</sld:Title>
			<sld:FeatureTypeStyle>
				<sld:Name>name</sld:Name>
				<sld:Rule>
					<sld:MaxScaleDenominator>3000000.0</sld:MaxScaleDenominator>
					<sld:PolygonSymbolizer>
						<sld:Stroke>
							<sld:CssParameter name="stroke">#ffb300</sld:CssParameter>
							<sld:CssParameter name="stroke-width">1</sld:CssParameter>
						</sld:Stroke>
					</sld:PolygonSymbolizer>
					<sld:PolygonSymbolizer>
						<sld:Fill>
							<sld:GraphicFill>
								<sld:Graphic>
									<sld:Mark>
										<sld:WellKnownName>ttf://Wingdings#108</sld:WellKnownName>
										<sld:Fill>
											<sld:CssParameter name="fill">#eaff00</sld:CssParameter>
										</sld:Fill>
									</sld:Mark>
									<sld:Opacity>1</sld:Opacity>
									<sld:Size>2</sld:Size>
								</sld:Graphic>
							</sld:GraphicFill>
						</sld:Fill>
						<VendorOption name="graphic-margin">2</VendorOption>
					</sld:PolygonSymbolizer>
				</sld:Rule>
				<!--1000-->
				<sld:Rule>
					<sld:MinScaleDenominator>13000</sld:MinScaleDenominator>
					<sld:MaxScaleDenominator>55000</sld:MaxScaleDenominator>
					<sld:TextSymbolizer>
					  <sld:Geometry>
						<ogc:Function name="labelPoint">
						  <ogc:PropertyName>the_geom</ogc:PropertyName>
						  <ogc:Literal>1.0</ogc:Literal>
						</ogc:Function>
					  </sld:Geometry>
						<sld:Label>
							<ogc:Literal>PLANTA FV</ogc:Literal>
							<ogc:PropertyName>NOMBRE</ogc:PropertyName>
						</sld:Label>
						<sld:Font>
							<sld:CssParameter name="font-family">Calibri</sld:CssParameter>
							<sld:CssParameter name="font-size">15</sld:CssParameter>
							<sld:CssParameter name="font-style">normal</sld:CssParameter>
							<sld:CssParameter name="font-weight">normal</sld:CssParameter>
						</sld:Font>
						<sld:LabelPlacement>
							<sld:PointPlacement>
								<sld:AnchorPoint>
									<sld:AnchorPointX>0.5</sld:AnchorPointX>
									<sld:AnchorPointY>0.5</sld:AnchorPointY>
								</sld:AnchorPoint>
							</sld:PointPlacement>
						</sld:LabelPlacement>
						<sld:Halo>
							<sld:Radius>1.5</sld:Radius>
							<sld:Fill>
								<sld:CssParameter name="fill">#FFFFFF</sld:CssParameter>
							</sld:Fill>
						</sld:Halo>
						<sld:Fill>
							<sld:CssParameter name="fill">#ffb300</sld:CssParameter>
						</sld:Fill>
					</sld:TextSymbolizer>
				</sld:Rule>
				<!--500-->
				<sld:Rule>
					<!-- <sld:MinScaleDenominator>16000</sld:MinScaleDenominator> -->
					<sld:MaxScaleDenominator>13000</sld:MaxScaleDenominator>
					<sld:TextSymbolizer>
<!-- 					  <sld:Geometry>
						<ogc:Function name="labelPoint">
						  <ogc:PropertyName>the_geom</ogc:PropertyName>
						  <ogc:Literal>1.0</ogc:Literal>
						</ogc:Function>
					  </sld:Geometry> -->
						<sld:Label>
							<ogc:Literal>PLANTA FV</ogc:Literal>
							<ogc:PropertyName>NOMBRE</ogc:PropertyName>
						</sld:Label>
						<sld:Font>
							<sld:CssParameter name="font-family">Calibri</sld:CssParameter>
							<sld:CssParameter name="font-size">15</sld:CssParameter>
							<sld:CssParameter name="font-style">normal</sld:CssParameter>
							<sld:CssParameter name="font-weight">normal</sld:CssParameter>
						</sld:Font>
						<sld:LabelPlacement>
							<sld:PointPlacement>
								<sld:AnchorPoint>
									<sld:AnchorPointX>0.5</sld:AnchorPointX>
									<sld:AnchorPointY>0.5</sld:AnchorPointY>
								</sld:AnchorPoint>
							</sld:PointPlacement>
						</sld:LabelPlacement>
						<sld:Halo>
							<sld:Radius>1.5</sld:Radius>
							<sld:Fill>
								<sld:CssParameter name="fill">#FFFFFF</sld:CssParameter>
							</sld:Fill>
						</sld:Halo>
						<sld:Fill>
							<sld:CssParameter name="fill">#ffb300</sld:CssParameter>
						</sld:Fill>
						<VendorOption name="spaceAround">-1</VendorOption>
						<VendorOption name="conflictResolution">false</VendorOption>
						<VendorOption name="autoWrap">150</VendorOption>
					</sld:TextSymbolizer>
				</sld:Rule>
			</sld:FeatureTypeStyle>
		</sld:UserStyle>
	</sld:NamedLayer>
</sld:StyledLayerDescriptor>